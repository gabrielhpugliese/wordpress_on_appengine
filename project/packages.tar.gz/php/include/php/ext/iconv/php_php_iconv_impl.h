#define PHP_ICONV_IMPL "glibc"
